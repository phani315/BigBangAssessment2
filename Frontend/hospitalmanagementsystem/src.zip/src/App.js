import logo from './logo.svg';
import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import Main from '../src/Components/Main/Main';
import Login from '../src/Components/LoginandSignUp/login';
import AdminLandingPage from './Components/Admin/Landingpage';
import ManageDoctors from './Components/ManageDoctors/ManageDoctors';
import LandingPage from './Components/Admin/Landingpage'; 
import PatientLandingPage from './Components/PatientLandingPage/PatientLandingPage';
import Register from './Components/Register/Register';
import DoctorProfile from './Components/DoctorLandingPage/doctorlandingpage';
import LandingPageProtectedRoute from './Components/Admin/LandingPageProtectedRoute';
function App() {
  var token;
  return (
    <BrowserRouter>



     <Routes>
    <Route path='/' element={<Login/>}/>
      <Route
            path="/landingPage"
            element={
              <LandingPageProtectedRoute token={token}>
                <LandingPage />
              </LandingPageProtectedRoute>
            }
          />
      <Route path='/managedoctors' element={<ManageDoctors/>}/>
      <Route path='/patientlandingpage' element={<PatientLandingPage/>}/>
      <Route path='/register' element={<Register/>}/>
      <Route path='/doctorlandingpage' element={<DoctorProfile/>}></Route> 


      


   </Routes> 
     
   </BrowserRouter>
  );
}

export default App;
